package com.cg.scheduleManagementApp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.scheduleManagementApp.beans.SessionManagement;

public interface ITrainingDAO extends JpaRepository<SessionManagement, Integer>{

}
